def execute():
    print("executed successfully")